﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ZipMoneyApi.Model
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public ObjectId Id { get; set; }

        [BsonElement("name")]
        [MaxLength(50)]
        public string name { get; set; }

        [BsonElement("email")]
        [Required]
        public string email { get; set; }

        [BsonElement("salary")]
        [Range(0, Int64.MaxValue, ErrorMessage = "salary should be greater than zero")]
        public string salary { get; set; }

        [BsonElement("expenses")]
        [Range(0, Int64.MaxValue, ErrorMessage = "expenses should be greater than zero")]
        public string expenses { get; set; }
    }
}
