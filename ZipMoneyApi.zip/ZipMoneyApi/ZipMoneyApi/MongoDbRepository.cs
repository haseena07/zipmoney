﻿
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ZipMoneyApi
{
    /// <summary>
    /// Mongo DB CRUD Operation
    /// </summary>
    public class MongoDbRepository<T>
    {
        /// <summary>
        /// Mongo Database Client object
        /// </summary>
        private readonly MongoClient MongoClient = null;

        /// <summary>
        /// Mongo DB Connection String
        /// </summary>
        private readonly String DBConnectionString;

        /// <summary>
        /// Mongo DB Database Name
        /// </summary>
        private readonly String DBName;

        /// <summary>
        /// Mongo DB Collection Name
        /// </summary>
        private readonly String DBCollection;


        /// <summary>
        /// Contructor to create a MongoClient Object
        /// </summary>
        /// <param name="DBConnectionString">Mongo DB Connection String</param>
        /// <param name="DbName">Mongo DB Database Name</param>
        /// <param name="CollectionName">Mongo DB Collection Name</param>
        public MongoDbRepository(string DBConnectionString, string DbName, String CollectionName)
        {
            this.DBName = DbName;
            this.DBConnectionString = DBConnectionString;
            this.DBCollection = CollectionName;
            MongoClient = new MongoClient(this.DBConnectionString);
        }


        /// <summary>
        /// Get all records from Mongo Db Collection
        /// </summary>
        /// <returns></returns>
        public List<T> GetAll()
        {
            IMongoDatabase database = null;
            IMongoCollection<T> dataCollection = null;
            try
            {
                database = MongoClient.GetDatabase(this.DBName);
                dataCollection = database.GetCollection<T>(this.DBCollection);
               return dataCollection.Find(t => true).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dataCollection = null;
                database = null;
            }
        }


        /// <summary>
        ///  Get specific record from Mongo Db Collection based on filter
        /// </summary>
        /// <param name="IdName">ID Property Name</param>
        /// <param name="IdValue">ID Property Value</param>
        /// <returns>Collection Item</returns>
        public T Get(String IdName, object IdValue)
        {
            IMongoDatabase database = null;
            IMongoCollection<T> dataCollection = null;
            try
            {
                database = MongoClient.GetDatabase(this.DBName);
                dataCollection = database.GetCollection<T>(this.DBCollection);

                var filter = Builders<T>.Filter.Eq(IdName, IdValue);

                return dataCollection.Find<T>(filter).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dataCollection = null;
                database = null;
            }
        }


        /// <summary>
        /// Create a new record in Mongo DB Collection
        /// </summary>
        /// <param name="item">Collection Item to create</param>
        /// <returns></returns>
        public T Create(T item)
        {
            IMongoDatabase database = null;
            IMongoCollection<T> dataCollection = null;
            try
            {
                database = MongoClient.GetDatabase(this.DBName);
                dataCollection = database.GetCollection<T>(this.DBCollection);
                dataCollection.InsertOne(item);
                return item;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dataCollection = null;
                database = null;
            }
        }


        /// <summary>
        /// Update specific record from Mongo Db Collection based on filter
        /// </summary>
        /// <param name="IdName">ID Property Name</param>
        /// <param name="IdValue">ID Property Value</param>
        /// <param name="item">Collection Item to replace</param>
        /// <returns>Boolean result</returns>
        public bool Update(String IdName, object IdValue, T item)
        {
            IMongoDatabase database = null;
            IMongoCollection<T> dataCollection = null;
            try
            {
                database = MongoClient.GetDatabase(this.DBName);
                dataCollection = database.GetCollection<T>(this.DBCollection);

                var filter = Builders<T>.Filter.Eq(IdName, IdValue);
                var row = dataCollection.ReplaceOne(filter, item);

                //var pi = typeof(T).GetProperty(collectionIdName);
                //var row = dataCollection.ReplaceOne(x => pi.GetValue(x) == filterIdValue, item);

                return row.MatchedCount > 0 ? true : false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dataCollection = null;
                database = null;
            }
        }


        /// <summary>
        ///  Remove specific record from Mongo Db Collection based on filter
        /// </summary>
        /// <param name="IdName">ID Property Name</param>
        /// <param name="IdValue">ID Property Value</param>
        /// <returns>Boolean result</returns>
        /// 
        public bool Remove(String IdName, object IdValue)
        {
            IMongoDatabase database = null;
            IMongoCollection<T> dataCollection = null;
            try
            {
                database = MongoClient.GetDatabase(this.DBName);
                dataCollection = database.GetCollection<T>(this.DBCollection);
                var filter = Builders<T>.Filter.Eq(IdName, IdValue);
                var row = dataCollection.DeleteOne(filter);
                return row.DeletedCount > 0 ? true : false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dataCollection = null;
                database = null;
            }
        }
    }
}
