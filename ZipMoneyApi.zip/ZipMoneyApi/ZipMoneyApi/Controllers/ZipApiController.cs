﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net;

namespace ZipMoneyApi.Controllers
{
    [Route("api/[controller]")]
    public class ZipApiController : Controller
    {
        // GET api/values
        [HttpGet]
        public IEnumerable<Model.User> Get()
        {
            AppSettingsUtility.BuildConfig(out AppSettings appSettings);

            MongoDbRepository<Model.User> databaseObj = new MongoDbRepository<Model.User>(appSettings.MongoDbConnectionString,
                appSettings.MongoDbDatabaseName,
                appSettings.MongoDbUserCollectionName);

            return databaseObj.GetAll();
        }




        [HttpGet("{id}")]
        public Model.User Get(string id, string value)
        {
            AppSettingsUtility.BuildConfig(out AppSettings appSettings);

            MongoDbRepository<Model.User> databaseObj = new MongoDbRepository<Model.User>(appSettings.MongoDbConnectionString,
                appSettings.MongoDbDatabaseName,
                appSettings.MongoDbUserCollectionName);

            return databaseObj.Get(id, value);
        }




        // POST api/values
        [HttpPost]
        public HttpResponseMessage Post([FromBody]Model.User value)
        {

            if (ModelState.IsValid)
            {
                AppSettingsUtility.BuildConfig(out AppSettings appSettings);

                MongoDbRepository<Model.User> databaseObj = new MongoDbRepository<Model.User>(appSettings.MongoDbConnectionString,
                    appSettings.MongoDbDatabaseName,
                    appSettings.MongoDbUserCollectionName);

                var user = databaseObj.Get("email", value.email);

                if (user == null)
                {
                    databaseObj.Create(value);
                    var account = new Model.Account
                    {
                        Type = "Demo",
                        CreatedDate = DateTime.UtcNow

                    };

                    MongoDbRepository<Model.Account> databaseObj2 = new MongoDbRepository<Model.Account>(appSettings.MongoDbConnectionString,
                   appSettings.MongoDbDatabaseName,
                   appSettings.MongoDbAccountCollectionName);
                    databaseObj2.Create(account);
                }

                return new HttpResponseMessage(HttpStatusCode.OK);
            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.NotAcceptable);
            }

        }

       
    }
}
