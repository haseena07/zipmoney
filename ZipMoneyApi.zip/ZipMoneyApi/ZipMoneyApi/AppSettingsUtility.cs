﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Reflection;

namespace ZipMoneyApi
{
    public class AppSettingsUtility
    {
        internal static void BuildConfig(out AppSettings appSettings)
        {
            appSettings = new AppSettings();
            try
            {
                var builder = new ConfigurationBuilder()
                      .SetBasePath(Directory.GetCurrentDirectory())
                      .AddJsonFile(GlobalConstants.APP_SETTINGS_APP_SETTINGS_FILE_NAME, optional: true, reloadOnChange: true);

                var configuration = builder.Build();

                configuration.GetSection(GlobalConstants.APP_SETTINGS_SECTION_APPSETTINGS_NAME).Bind(appSettings);
            }
            catch (Exception ex)
            {
            }
        }

    }
}
