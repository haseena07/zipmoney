﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ZipMoneyApi
{
    public class AppSettings
    {

       
        #region mongo db related string

        /// <summary>
        /// Gets or sets the mongo database connection string.
        /// </summary>
        /// <value>
        /// The mongo database connection string.
        /// </value>
        public string MongoDbConnectionString { get; set; }

        /// <summary>
        /// Gets or sets the name of the mongo database database.
        /// </summary>
        /// <value>
        /// The name of the mongo database database.
        /// </value>
        public string MongoDbDatabaseName { get; set; }

        /// <summary>
        /// Gets or sets the name of the mongo database user collection.
        /// </summary>
        /// <value>
        /// The name of the mongo database raw data collection.
        /// </value>
        public string MongoDbUserCollectionName { get; set; }

        /// <summary>
        /// Gets or sets the name of the mongo database account collection.
        /// </summary>
        /// <value>
        /// The name of the mongo database raw data collection.
        /// </value>
        public string MongoDbAccountCollectionName { get; set; }


        /// <summary>
        /// Gets or sets the name of the mongo database collection Id parameter name.
        /// </summary>
        /// <value>
        /// The name of the mongo database collection Id parameter name.
        /// </value>
        public string MongoDbCollectionIdParameterName { get; set; }

        #endregion


        
       
    }
}
