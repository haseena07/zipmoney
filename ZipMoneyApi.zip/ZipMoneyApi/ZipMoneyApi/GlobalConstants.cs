﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ZipMoneyApi
{
    public class GlobalConstants
    {
        /// <summary>
        /// The application settings application settings file name
        /// </summary>
        public const string APP_SETTINGS_APP_SETTINGS_FILE_NAME = "appsettings.json";

        /// <summary>
        /// The application settings section appsettings name
        /// </summary>
        public const string APP_SETTINGS_SECTION_APPSETTINGS_NAME = "AppSettings";
    }
}
